<?php
	
	require_once("site_settings.php");
	include('config.php');
	include('session.php');
	
	
	$ii="0";
?>
<!DOCTYPE html>
<html lang="en">
<head>

  <!-- Basic Page Needs
  –––––––––––––––––––––––––––––––––––––––––––––––––– -->
  <meta charset="utf-8">
  <title><?php echo $site_title_int; ?> | Profile </title>
  <meta name="<?php echo $site_sologun; ?>" content="">
  <meta name="Nazmul Alam Shuvo" content="">

  <!-- Mobile Specific Metas
  –––––––––––––––––––––––––––––––––––––––––––––––––– -->

  <meta name="viewport" content="width=device-width, initial-scale=1">

  <!-- FONT
  –––––––––––––––––––––––––––––––––––––––––––––––––– -->
  <link href="//fonts.googleapis.com/css?family=Raleway:400,300,600" rel="stylesheet" type="text/css">

  <!-- CSS
  –––––––––––––––––––––––––––––––––––––––––––––––––– -->
  <link rel="stylesheet" href="css/normalize.css">
  <link rel="stylesheet" href="css/skeleton.css">
  	
	<link rel="stylesheet" href="css/col.css" media="all">
	<link rel="stylesheet" href="css/5cols.css" media="all">
	
<style type="text/css">

a { text-decoration : none; color : #000; }

</style>

  <!-- Favicon
  –––––––––––––––––––––––––––––––––––––––––––––––––– -->
  <link rel="icon" type="image/png" href="images/favicon.png">


</head>
<body bgcolor="#ececec">

  <!-- Primary Page Layout
  –––––––––––––––––––––––––––––––––––––––––––––––––– -->
  <div class="container">
  <br>
   <div class="row">
   <div class="eleven columns"><a href="index.php"><h4><?php echo $login_session_hostelname; ?></a></h4>  <h6><?php echo $site_sologun; ?></h6></div>
    <div class="one column"><font color="red"><strong><a href="logout.php">Logout</a></strong></font></div>
    
  </div>
  <hr>
					<?php 
								
								$id="";
								$tamount = "";
								$conn = mysql_connect($database_server, $database_username, $database_password);
								$sql = "SELECT * from users WHERE hostel = '$login_session_hostelname' AND `username`= '$login_session_username'";

								mysql_select_db('$database');
								$retval = mysql_query( $sql, $conn );
								
								$row = mysql_fetch_array($retval, MYSQL_ASSOC)
								
									
									
								
					
					?>
					
					<?php
						
							$erp="";
							$msg = "";
							if(isset($_GET['erp'])){
								
								$erp=$_GET['erp'];
								$id=$_GET['id'];
							}
							$erpp="";
							if(isset($_GET['erpp'])){
								
								$erpp=$_GET['erpp'];
							}
							if($erpp=='ok'){
								
								$msg = "Sussesful Update.";
							}
							
								if($erp=='save')
							{
								
								$pass1 = $_POST['pass1'];
								$pass2 = $_POST['pass2'];
								
								
								$updateBy = $login_session_username;
								$hostel= $login_session_hostelname;
								if($pass1 == $pass2){
									
									$password_new = $pass1;
									$a_sql=mysql_query("UPDATE users SET password='$password_new' WHERE id='$id'");
								if($a_sql)
								{
									
									header("Location: profile.php?erpp=ok");
									$msg = "Sussesful Update.";
								}
									
								}else{
									$msg = "Password don't match";
								}
								
							} ?><h6><font color = "green"><?php echo $msg; ?></font></h6><?php
							
							if($erp == 'pass'){ ?>
							
								
								<form action="profile.php?erp=save&id=<?php echo $row['id']; ?>" method="post">
								<label for="exampleEmailInput">Your Password</label>
								<input class="u-full-width" name="pass1" type="text" placeholder="******" id="exampleEmailInput">
								<label for="exampleEmailInput">Re-Password</label>
								<input class="u-full-width" name="pass2" type="text" placeholder="******" id="exampleEmailInput">
								
								<input class="button-primary" name="save" type="submit" value="Save">
								</form>
							<?php }
							
						
						
					?>
					
					  <font align="center">
	<h4>Profile </h4>
	
  </font>
					
					<div class="row">
					<div class="two columns"><strong>Username: </strong></div>
					<div class="ten columns"><font color="red"><?php echo $row['username']; ?></font></div>
				    </div>
					<div class="row">
					<div class="two columns"><strong>Full Name: </strong></div>
					<div class="ten columns"><?php echo $row['name']; ?></div>
				    </div>
					<div class="row">
					<div class="two columns"><strong>NID Number: </strong></div>
					<div class="ten columns"><?php echo $row['nid']; ?></div>
				    </div>
					<div class="row">
					<div class="two columns"><strong>Mobile: </strong></div>
					<div class="ten columns"><?php echo $row['mobile']; ?></div>
				    </div>
					<div class="row">
					<div class="two columns"><strong>Your Hostel: </strong></div>
					<div class="ten columns"><?php echo $row['hostel']; ?></div>
				    </div>
					<div class="row">
					<div class="two columns"><strong>You are: </strong></div>
					<div class="ten columns"><font color="red"><?php $pow=$row['power']; $status=""; if($pow==1){ $status="Admin";}else{$status="User";} echo $status; ?></font></div>
				    </div>
					<br>
					<form action="profile.php?erp=pass&id=<?php echo $row['id']; ?>" method="post">
					<input class="button-primary" name="pass" type="submit" value="Change Password">
					</form>
  <br>
  <br>
  <br>
  <hr>
 <font size="2px" align="center">(c) <?php echo $site_title; ?></font>
  
<br><br>
  </div>
  

		
  
 

<!-- End Document
  –––––––––––––––––––––––––––––––––––––––––––––––––– -->
</body>
</html>
