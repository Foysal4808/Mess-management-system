<?php
	
	require_once("../site_settings.php");
		include('../config.php');
	include('../session.php');
	
	if($login_session==1)
	{
	  
		//none
	  
	}else{
		
		header("Location: ../index.php");
	}
	
	
	$msg = "";
	if(isset($_POST['add']))
	{
		$username = $_POST['username'];
		$password = $_POST['password'];
		$name = $_POST['boders'];
		$mobile = $_POST['mobile'];
		$nid = $_POST['nid'];
		$hostel= $login_session_hostelname;
		

// Create connection
$conn = new mysqli($database_server, $database_username, $database_password, $database);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 

$sql = "INSERT INTO `$database`.`users` (`id`, `username`, `password`, `power`, `hostel`, `mobile`, `nid`, `name`) VALUES (NULL, '$username', '$password', '0', '$hostel', '$mobile', '$nid', '$name');";

if ($conn->query($sql) === TRUE) {
    $msg = "Boder Added successfully";
} else {
    $msg = "Error: " . $sql . "<br>" . $conn->error;
}
	}


	
?>
<!DOCTYPE html>
<html lang="en">
<head>

  <!-- Basic Page Needs
  –––––––––––––––––––––––––––––––––––––––––––––––––– -->
  <meta charset="utf-8">
  <title><?php echo $site_title_int; ?> | Add Bodres</title>
  <meta name="<?php echo $site_sologun; ?>" content="">
  <meta name="Nazmul Alam Shuvo" content="">

  <!-- Mobile Specific Metas
  –––––––––––––––––––––––––––––––––––––––––––––––––– -->
  <meta name="viewport" content="width=device-width, initial-scale=1">

  <!-- FONT
  –––––––––––––––––––––––––––––––––––––––––––––––––– -->
  <link href="//fonts.googleapis.com/css?family=Raleway:400,300,600" rel="stylesheet" type="text/css">

  <!-- CSS
  –––––––––––––––––––––––––––––––––––––––––––––––––– -->
  <link rel="stylesheet" href="css/normalize.css">
  <link rel="stylesheet" href="css/skeleton.css">
<style type="text/css">

a { text-decoration : none; color : #000; }

</style>
  <!-- Favicon
  –––––––––––––––––––––––––––––––––––––––––––––––––– -->
  <link rel="icon" type="image/png" href="images/favicon.png">

</head>
<body>

  <!-- Primary Page Layout
  –––––––––––––––––––––––––––––––––––––––––––––––––– -->
  <div class="container">
  <br>
   <div class="row">
   <div class="eleven columns"><a href="index.php"><h4><?php echo $login_session_hostelname; ?></h4> </a> <h6><?php echo $site_sologun; ?></h6></div>
    <div class="one column"><font color="red"><a href="../logout.php"><strong>Logout</strong></a></font></div>
    
  </div>
  <hr>
	
  <font align="center">
	<h4>Add Boders</h4>
	<h6><font color = "green"><?php echo $msg; ?></font></h6>
  </font>
  <form action="add_boders.php" method="post">
	
		<label for="exampleEmailInput">Username</label>
	    <input class="u-full-width" type="text" name="username" placeholder="Ex: naim" id="Naim">
		<label for="exampleEmailInput">Password</label>
	    <input class="u-full-width" type="password" name="password" placeholder="********" id="Naim">
		<label for="exampleEmailInput">Boders Name</label>
	    <input class="u-full-width" type="text" name="boders" placeholder="Ex: Naim Hasan" id="Naim">
		<label for="exampleEmailInput">Mobile No.</label>
	    <input class="u-full-width" type="text" name="mobile" placeholder="Ex: 017xxx" id="Naim">
		<label for="exampleEmailInput">NID No.</label>
	    <input class="u-full-width" type="text" name="nid" placeholder="Ex: 1996" id="1996XX">
		
		
		<input class="button-primary" type="submit" name="add" value="Add Boders">
		
  </form>
 <br>
  <hr>
 <font size="2px" align="center">(c) <?php echo $site_title; ?></font>
  
<br><br>
  </div>

<!-- End Document
  –––––––––––––––––––––––––––––––––––––––––––––––––– -->
</body>
</html>
