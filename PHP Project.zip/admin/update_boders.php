<?php
	
	require_once("../site_settings.php");
		include('../config.php');
	include('../session.php');
	
	if($login_session==1)
	{
	  
		//none
	  
	}else{
		
		header("Location: ../index.php");
	}
	
	
	$id="";
	$erp="";
	$msg = "";
	if(isset($_GET['erp'])){
		
		$erp=$_GET['erp'];
		$id=$_GET['id'];
	}

	if($erp=='save')
	{
		$username = $_POST['username'];
		$password = $_POST['password'];
		$name = $_POST['boders'];
		$mobile = $_POST['mobile'];
		$nid = $_POST['nid'];
		$hostel= $login_session_hostelname;
		
		$a_sql=mysql_query("UPDATE users SET username='$username', password='password', hostel='$hostel', mobile='$mobile', nid='$nid', name='$name' WHERE id='$id'");
		if($a_sql)
		{
			header("Location: boders_list.php");
		}
	}

	

	
?>
<!DOCTYPE html>
<html lang="en">
<head>

  <!-- Basic Page Needs
  –––––––––––––––––––––––––––––––––––––––––––––––––– -->
  <meta charset="utf-8">
  <title><?php echo $site_title_int; ?> | Update Boders</title>
  <meta name="<?php echo $site_sologun; ?>" content="">
  <meta name="Nazmul Alam Shuvo" content="">

  <!-- Mobile Specific Metas
  –––––––––––––––––––––––––––––––––––––––––––––––––– -->
  <meta name="viewport" content="width=device-width, initial-scale=1">

  <!-- FONT
  –––––––––––––––––––––––––––––––––––––––––––––––––– -->
  <link href="//fonts.googleapis.com/css?family=Raleway:400,300,600" rel="stylesheet" type="text/css">

  <!-- CSS
  –––––––––––––––––––––––––––––––––––––––––––––––––– -->
  <link rel="stylesheet" href="css/normalize.css">
  <link rel="stylesheet" href="css/skeleton.css">
<style type="text/css">

a { text-decoration : none; color : #000; }

</style>
  <!-- Favicon
  –––––––––––––––––––––––––––––––––––––––––––––––––– -->
  <link rel="icon" type="image/png" href="images/favicon.png">

</head>
<body>

  <!-- Primary Page Layout
  –––––––––––––––––––––––––––––––––––––––––––––––––– -->
  <div class="container">
  <br>
   <div class="row">
   <div class="eleven columns"><a href="index.php"><h4><?php echo $login_session_hostelname; ?></h4> </a> <h6><?php echo $site_sologun; ?></h6></div>
    <div class="one column"><font color="red"><a href="../logout.php"><strong>Logout</strong></a></font></div>
    
  </div>
  <hr>
	
  <font align="center">
	<h4>Update Boders</h4>
	<h6><font color = "green"><?php echo $msg; ?></font></h6>
  </font>
  
    <?php
	
	if($erp=='update'){
		
		$id=$_GET['id'];
		$row=mysql_query("SELECT * FROM users WHERE id = $id");
		$st_row=mysql_fetch_array($row);
		
	?>
		<form action="update_boders.php?erp=save&id=<?php echo $id; ?>" method="post">
			<label for="exampleEmailInput">Username</label>
	    <input class="u-full-width" type="text" name="username" value="<?php echo $st_row['username'];?>" id="Naim">
		<label for="exampleEmailInput">Password</label>
	    <input class="u-full-width" type="password" name="password" value="<?php echo $st_row['password'];?>" id="Naim">
		<label for="exampleEmailInput">Boders Name</label>
	    <input class="u-full-width" type="text" name="boders" value="<?php echo $st_row['name'];?>" id="Naim">
		<label for="exampleEmailInput">Mobile No.</label>
	    <input class="u-full-width" type="text" name="mobile" value="<?php echo $st_row['mobile'];?>" id="Naim">
		<label for="exampleEmailInput">NID No.</label>
	    <input class="u-full-width" type="text" name="nid" value="<?php echo $st_row['nid'];?>" id="1996XX">
		
		<input class="button-primary" type="submit" name="save" value="Update Meal">
		
  </form>
		
	<?php }else{ ?>
		
		
	<?php } ?>
  
  
  
 <br>
  <hr>
 <font size="2px" align="center">(c) <?php echo $site_title; ?></font>
  
<br><br>
  </div>

<!-- End Document
  –––––––––––––––––––––––––––––––––––––––––––––––––– -->
</body>
</html>
