<?php
	
		require_once("../site_settings.php");
		include('../config.php');
	    include('../session.php');
			
	if($login_session==1)
	{
	  
		//none
	  
	}else{
		
		header("Location: ../index.php");
	}
	
	if(isset($_POST['search']))
	{
		
		$value = $_POST['value'];
		$query = "SELECT * FROM clening WHERE `hostel`= '$login_session_hostelname' AND CONCAT (`id`, `username`, `date`)LIKE '%".$value."%'";
		$search_result = search_table($query);
	}
	else
	{
		$popo = $login_session_hostelname;
		$query = "SELECT DISTINCT * FROM `clening` WHERE `hostel`= '$popo' ORDER BY `id` ASC";
		$search_result = search_table($query);
	}
	function search_table($query)
	{
		include('../config.php');
		$connect = mysqli_connect($database_server,$database_username,$database_password,$database);
		$search_result = mysqli_query($connect, $query);
		return $search_result;
	}
	$erp="";
	$msg="";
	if(isset($_GET['erp'])){
		
		$erp=$_GET['erp'];
	}
	
	if($erp=='delete'){
		
		$id=$_GET['id'];
		$delete = mysql_query("DELETE FROM `$database`.`clening` WHERE `clening`.`id` = $id");
		if($delete){
			
			header("Location: clening.php");
			
		}else{
			
			$msg="Delete Faield!!";
		}
		
	}
	

?>
<!DOCTYPE html>
<html lang="en">
<head>

  <!-- Basic Page Needs
  –––––––––––––––––––––––––––––––––––––––––––––––––– -->
  <meta charset="utf-8">
  <title><?php echo $site_title_int; ?> | Clenning Schedul</title>
  <meta name="<?php echo $site_sologun; ?>" content="">
  <meta name="Nazmul Alam Shuvo" content="">

  <!-- Mobile Specific Metas
  –––––––––––––––––––––––––––––––––––––––––––––––––– -->
  <meta name="viewport" content="width=device-width, initial-scale=1">

  <!-- FONT
  –––––––––––––––––––––––––––––––––––––––––––––––––– -->
  <link href="//fonts.googleapis.com/css?family=Raleway:400,300,600" rel="stylesheet" type="text/css">

  <!-- CSS
  –––––––––––––––––––––––––––––––––––––––––––––––––– -->
  <link rel="stylesheet" href="css/normalize.css">
  <link rel="stylesheet" href="css/skeleton.css">
<style type="text/css">

a { text-decoration : none; color : #000; }

.myButton {
	-moz-box-shadow:inset 1px -11px 12px 0px #ffffff;
	-webkit-box-shadow:inset 1px -11px 12px 0px #ffffff;
	box-shadow:inset 1px -11px 12px 0px #ffffff;
	background-color:transparent;
	-moz-border-radius:6px;
	-webkit-border-radius:6px;
	border-radius:6px;
	border:2px solid #dcdcdc;
	display:inline-block;
	cursor:pointer;
	color:#777777;
	font-family:Arial;
	font-size:15px;
	font-weight:bold;
	padding:6px 15px;
	text-decoration:none;
	text-shadow:0px 5px 7px #ffffff;
}
.myButton:hover {
	background-color:transparent;
}
.myButton:active {
	position:relative;
	top:1px;
}



</style>
  <!-- Favicon
  –––––––––––––––––––––––––––––––––––––––––––––––––– -->
  <link rel="icon" type="image/png" href="images/favicon.png">

</head>
<body>

  <!-- Primary Page Layout
  –––––––––––––––––––––––––––––––––––––––––––––––––– -->
  <div class="container">
  <br>
   <div class="row">
   <div class="eleven columns"><a href="index.php"><h4><?php echo $login_session_hostelname; ?></h4>  </a><h6><?php echo $site_sologun; ?></h6></div>
    <div class="one column"><font color="red"><strong><a style="text-decoration : none;" href="../logout.php">Logout</a></strong></font></div>
    
  </div>
  <hr>
	
  <font align="center">
	<h4>Clenning Schedul</h4>
	<h6><font color = "green"><?php echo $msg; ?></font></h6>
  </font>
  
  <form action="clening.php" method="post">
  <label for="exampleEmailInput">Boders Name</label>
	<input class="u-full-width" type="text" name="value" placeholder="Ex: Naim" id="Naim">
	<input class="button-primary" type="submit" name="search" value="Search">
		</form>
	
    
     <div class="row">
		
		<p align="right"><a href="add_clening.php" class="myButton">Add Schedul</a></p>
		
	 </div>
		
  <table class="u-full-width">
  <thead>
    <tr>
		
      <th>Boders Name</th>
      <th>Clening date</th>
	  <th>Action</th>
      
    </tr>
  </thead>
  <tbody>
		
		<?php while($row = mysqli_fetch_array($search_result))
   {?>
	
   
	  <tr>
      <td><?php echo $row['username']; ?></td>
	  <td><?php echo $row['date']; ?></td>
	    
    
	  
      <td><font color = "red"><b><a href='update_clening.php?erp=update&id=<?php echo $row['id']; ?>'>Update</a> | <a href='clening.php?erp=delete&id=<?php echo $row['id']; ?>'>Delete</a></b></font></td>
    </tr>
   <?php }; ?>

  </tbody>
</table>

 <br>
  <hr>
 <font size="2px" align="center">(c) <?php echo $site_title; ?></font>
  
<br><br>
  </div>

<!-- End Document
  –––––––––––––––––––––––––––––––––––––––––––––––––– -->
</body>
</html>
