<?php
	
	require_once("../site_settings.php");
	include('../config.php');
	include('../session.php');
	
	if($login_session==1)
	{
	  
		//none
	  
	}else{
		
		header("Location: ../index.php");
	}
	$ii="0";
?>
<!DOCTYPE html>
<html lang="en">
<head>

  <!-- Basic Page Needs
  –––––––––––––––––––––––––––––––––––––––––––––––––– -->
  <meta charset="utf-8">
  <title><?php echo $site_title_int; ?> | Admin Dashboard </title>
  <meta name="<?php echo $site_sologun; ?>" content="">
  <meta name="Nazmul Alam Shuvo" content="">

  <!-- Mobile Specific Metas
  –––––––––––––––––––––––––––––––––––––––––––––––––– -->

  <meta name="viewport" content="width=device-width, initial-scale=1">

  <!-- FONT
  –––––––––––––––––––––––––––––––––––––––––––––––––– -->
  <link href="//fonts.googleapis.com/css?family=Raleway:400,300,600" rel="stylesheet" type="text/css">

  <!-- CSS
  –––––––––––––––––––––––––––––––––––––––––––––––––– -->
  <link rel="stylesheet" href="css/normalize.css">
  <link rel="stylesheet" href="css/skeleton.css">
  	
	<link rel="stylesheet" href="css/col.css" media="all">
	<link rel="stylesheet" href="css/5cols.css" media="all">
	
<style type="text/css">

a { text-decoration : none; color : #000; }

</style>

  <!-- Favicon
  –––––––––––––––––––––––––––––––––––––––––––––––––– -->
  <link rel="icon" type="image/png" href="images/favicon.png">

  <script type="text/javascript">
tday=new Array("Sunday","Monday","Tuesday","Wednesday","Thursday","Friday","Saturday");
tmonth=new Array("January","February","March","April","May","June","July","August","September","October","November","December");

function GetClock(){
var d=new Date();
var nday=d.getDay(),nmonth=d.getMonth(),ndate=d.getDate(),nyear=d.getYear(),nhour=d.getHours(),nmin=d.getMinutes(),ap;
     if(nhour==0){ap=" AM";nhour=12;}
else if(nhour<12){ap=" AM";}
else if(nhour==12){ap=" PM";}
else if(nhour>12){ap=" PM";nhour-=12;}

if(nyear<1000) nyear+=1900;
if(nmin<=9) nmin="0"+nmin;

document.getElementById('clockbox').innerHTML=""+tday[nday]+", "+tmonth[nmonth]+" "+ndate+", "+nyear+" "+nhour+":"+nmin+ap+"";
}

window.onload=function(){
GetClock();
setInterval(GetClock,1000);
}
</script>

</head>
<body bgcolor="#ececec">

  <!-- Primary Page Layout
  –––––––––––––––––––––––––––––––––––––––––––––––––– -->
  <div class="container">
  <br>
   <div class="row">
   <div class="eleven columns"><a href="index.php"><h4><?php echo $login_session_hostelname; ?></a></h4>  <h6><?php echo $site_sologun; ?></h6></div>
    <div class="one column"><font color="red"><strong><a href="../logout.php">Logout</a></strong></font></div>
    
  </div>
  <hr>
					<div class="section group">
					
					<?php 
								$conn = mysql_connect($database_server, $database_username, $database_password);
								$sql = "SELECT * from users WHERE hostel = '$login_session_hostelname'";

								mysql_select_db('$database');
								$retval = mysql_query( $sql, $conn );
								
								while($row = mysql_fetch_array($retval, MYSQL_ASSOC))
								{
									
									$ii++;
								}
					
					?>
						<div class="col span_1_of_5"><a href="boders_list.php">
					<div class="row" style="background-color: #dddddd; color: #323434;" align="center">
					<p align="center"><br>Total Boders<br><font color="#0a857e" size="5em"><?php echo $ii; ?></font></p>
					</a></div>
					</div>
					<?php 
								$account = "";
								$conn = mysql_connect($database_server, $database_username, $database_password);
								$sql = "SELECT * from account WHERE hostel = '$login_session_hostelname'";

								mysql_select_db('$database');
								$retval = mysql_query( $sql, $conn );
								
								while($row = mysql_fetch_array($retval, MYSQL_ASSOC))
								{
									$account= $account + $row['taka'] + $row['previous'];
									
								}
					
					?>
				
					
						<div class="col span_1_of_5"><a href="fund_list.php">
					<div class="row" style="background-color: #dddddd; color: #323434;" align="center">
					<p align="center"><br>Total Fund<br><font color="#0a857e" size="5em"><?php echo $account; ?></font></p>
					</a></div>
					</div>
						<?php 
								$meal = "";
								$conn = mysql_connect($database_server, $database_username, $database_password);
								$sql = "SELECT * from meal WHERE hostel = '$login_session_hostelname'";

								mysql_select_db('$database');
								$retval = mysql_query( $sql, $conn );
								
								while($row = mysql_fetch_array($retval, MYSQL_ASSOC))
								{
									$meal= $meal + $row['meal'] + $row['guestMeal'];
									
								}
					
					?>
						<div class="col span_1_of_5"><a href="meal_list.php">
					<div class="row" style="background-color: #dddddd; color: #323434;" align="center">
					<p align="center"><br>Total Meal<br><font color="#0a857e" size="5em"><?php echo $meal;?></font></p>
					</a></div>
					</div>
					<?php 
								$tamount = "";
								$conn = mysql_connect($database_server, $database_username, $database_password);
								$sql = "SELECT * from bazaars WHERE hostel = '$login_session_hostelname'";

								mysql_select_db('$database');
								$retval = mysql_query( $sql, $conn );
								
								while($row = mysql_fetch_array($retval, MYSQL_ASSOC))
								{
									$tamount= $tamount + $row['amount'];
									
								}
					
					?>
					
						<div class="col span_1_of_5"><a href="bazaar_list.php">
					<div class="row" style="background-color: #dddddd; color: #323434;" align="center">
					<p align="center"><br>Total Bazaar<br><font color="#0a857e" size="5em"><?php echo $tamount; ?></font></p>
					</a></div>
					</div>
					
					<div class="col span_1_of_5"><a href="log.php">
					<div class="row" style="background-color: #dddddd; color: #323434;" align="center">
					<p align="center"><br>Meal Rate Calculator<br><font color="#0a857e" size="5em"><?php $meal_rate="0"; if($tamount !=0 || $meal !=0){$meal_rate = $tamount / $meal; }echo (int)$meal_rate+1; ?></font></p>
					</a></div>
					</div>
			
				</div>
				
				<div class="section group">
						<div class="col span_1_of_5"><a href="add_meal.php">
					<div class="row" style="background-color: #dddddd; color: #323434;" align="center">
					<p align="center"><br><font color="#0a857e" size="5em">Add Meal</font></p>
					</a></div>
					</div>
					
						<div class="col span_1_of_5"><a href="add_bazaar.php">
					<div class="row" style="background-color: #dddddd; color: #323434;" align="center">
					<p align="center"><br><font color="#0a857e" size="5em">Add Bazaar</font></p>
					</a></div>
					</div>
					
						<div class="col span_1_of_5"><a href="clening.php">
					<div class="row" style="background-color: #dddddd; color: #323434;" align="center">
					<p align="center"><br><font color="#0a857e" size="5em">Washroom</font></p>
					</a></div>
					</div>
					
						<div class="col span_1_of_5"><a href="notice.php">
					<div class="row" style="background-color: #dddddd; color: #323434;" align="center">
					<p align="center"><br><font color="#0a857e" size="5em">Notice</font></p>
					
					</a></div>
					</div>
					
					<div class="col span_1_of_5"><a href="profile.php">
					<div class="row" style="background-color: #dddddd; color: #323434;" align="center">
					<p align="center"><br><font color="#0a857e" size="5em">Profile</font></p>
					</a></div>
					</div>
			
				</div>

  
  <h3>Welcome <font color="blue"align="center"><?php echo $login_session_username; ?>!</h3></font>
  <div id="clockbox" style="font:10pt Arial; color:#8c8c8c;"></div>
  <br>
  <h4>Notice::</h4>
  <?php 
								$tamount = "";
								$conn = mysql_connect($database_server, $database_username, $database_password);
								$sql = "SELECT * from notice WHERE hostel = '$login_session_hostelname'";

								mysql_select_db('$database');
								$retval = mysql_query( $sql, $conn );
								
								while($row = mysql_fetch_array($retval, MYSQL_ASSOC))
								{
									?>
									<p><?php echo $row['notice']; ?> <br><font color="#097086" size="1em">Update by - <?php echo $row['updateBy'];?></font></p>
									<?php 
									
								}
					
					?>
  
  

  <br>
  <hr>
 <font size="2px" align="center">(c) <?php echo $site_title; ?></font>
  
<br><br>
  </div>
  

		
  
 

<!-- End Document
  –––––––––––––––––––––––––––––––––––––––––––––––––– -->
</body>
</html>
