<?php
	
	require_once("../site_settings.php");
	include('../config.php');
	include('../session.php');
	
	if($login_session==1)
	{
	  
		//none
	  
	}else{
		
		header("Location: ../index.php");
	}
	$ii="0";
?>
<!DOCTYPE html>
<html lang="en">
<head>

  <!-- Basic Page Needs
  –––––––––––––––––––––––––––––––––––––––––––––––––– -->
  <meta charset="utf-8">
  <title><?php echo $site_title_int; ?> | Admin Notice Update </title>
  <meta name="<?php echo $site_sologun; ?>" content="">
  <meta name="Nazmul Alam Shuvo" content="">

  <!-- Mobile Specific Metas
  –––––––––––––––––––––––––––––––––––––––––––––––––– -->

  <meta name="viewport" content="width=device-width, initial-scale=1">

  <!-- FONT
  –––––––––––––––––––––––––––––––––––––––––––––––––– -->
  <link href="//fonts.googleapis.com/css?family=Raleway:400,300,600" rel="stylesheet" type="text/css">

  <!-- CSS
  –––––––––––––––––––––––––––––––––––––––––––––––––– -->
  <link rel="stylesheet" href="css/normalize.css">
  <link rel="stylesheet" href="css/skeleton.css">
  	
	<link rel="stylesheet" href="css/col.css" media="all">
	<link rel="stylesheet" href="css/5cols.css" media="all">
	
<style type="text/css">

a { text-decoration : none; color : #000; }

</style>

  <!-- Favicon
  –––––––––––––––––––––––––––––––––––––––––––––––––– -->
  <link rel="icon" type="image/png" href="images/favicon.png">

  <script type="text/javascript">
tday=new Array("Sunday","Monday","Tuesday","Wednesday","Thursday","Friday","Saturday");
tmonth=new Array("January","February","March","April","May","June","July","August","September","October","November","December");

function GetClock(){
var d=new Date();
var nday=d.getDay(),nmonth=d.getMonth(),ndate=d.getDate(),nyear=d.getYear(),nhour=d.getHours(),nmin=d.getMinutes(),ap;
     if(nhour==0){ap=" AM";nhour=12;}
else if(nhour<12){ap=" AM";}
else if(nhour==12){ap=" PM";}
else if(nhour>12){ap=" PM";nhour-=12;}

if(nyear<1000) nyear+=1900;
if(nmin<=9) nmin="0"+nmin;

document.getElementById('clockbox').innerHTML=""+tday[nday]+", "+tmonth[nmonth]+" "+ndate+", "+nyear+" "+nhour+":"+nmin+ap+"";
}

window.onload=function(){
GetClock();
setInterval(GetClock,1000);
}
</script>

</head>
<body bgcolor="#ececec">

  <!-- Primary Page Layout
  –––––––––––––––––––––––––––––––––––––––––––––––––– -->
  <div class="container">
  <br>
   <div class="row">
   <div class="eleven columns"><a href="index.php"><h4><?php echo $login_session_hostelname; ?></a></h4>  <h6><?php echo $site_sologun; ?></h6></div>
    <div class="one column"><font color="red"><strong><a href="../logout.php">Logout</a></strong></font></div>
    
  </div>
  <hr>
					<?php 
								
								$id="";
								$tamount = "";
								$conn = mysql_connect($database_server, $database_username, $database_password);
								$sql = "SELECT * from notice WHERE hostel = '$login_session_hostelname'";

								mysql_select_db('$database');
								$retval = mysql_query( $sql, $conn );
								
								$row = mysql_fetch_array($retval, MYSQL_ASSOC)
								
									
									
								
					
					?>
					
					<?php
						
							$erp="";
							$msg = "";
							if(isset($_GET['erp'])){
								
								$erp=$_GET['erp'];
								$id=$_GET['id'];
							}

							if($erp=='save')
							{
								$notice = $_POST['notice'];
								$updateBy = $login_session_username;
								$hostel= $login_session_hostelname;
								
								$a_sql=mysql_query("UPDATE notice SET notice='$notice', updateBy='$updateBy' WHERE id='$id'");
								if($a_sql)
								{
									$msg = "Sussesful Update.";
									header("Location: notice.php");
									
								}
							}
						
					?>
					<form action="notice.php?erp=save&id=<?php echo $row['id']; ?>" method="post">
					<font color="" > <?php echo $msg; ?></font>
					 <label for="exampleMessage">Update Notice</label>
					<textarea class="u-full-width" name="notice" placeholder="<?php echo $row['notice']; ?>" id="exampleMessage"></textarea>
					
					<input class="button-primary" name="save" type="submit" value="Update">
					</form>
  <br>
  <hr>
 <font size="2px" align="center">(c) <?php echo $site_title; ?></font>
  
<br><br>
  </div>
  

		
  
 

<!-- End Document
  –––––––––––––––––––––––––––––––––––––––––––––––––– -->
</body>
</html>
