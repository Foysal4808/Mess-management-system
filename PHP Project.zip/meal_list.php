<?php
	
		require_once("site_settings.php");
		include('config.php');
	    include('session.php');
			
	
	
	if(isset($_POST['search']))
	{
		
		$value = $_POST['value'];
		$query = "SELECT * FROM meal WHERE `hostel`= '$login_session_hostelname' AND CONCAT (`id`, `bodersName`, `meal`, `guestMeal`, `date`)LIKE '%".$value."%'";
		$search_result = search_table($query);
	}
	else
	{
		$popo = $login_session_hostelname;
		$query = "SELECT DISTINCT * FROM `meal` WHERE `hostel`= '$popo' AND `bodersName`= '$login_session_username' ORDER BY `date` ASC";
		$search_result = search_table($query);
	}
	function search_table($query)
	{
		include('config.php');
		$connect = mysqli_connect($database_server,$database_username,$database_password,$database);
		$search_result = mysqli_query($connect, $query);
		return $search_result;
	}
	$erp="";
	$msg="";
	if(isset($_GET['erp'])){
		
		$erp=$_GET['erp'];
	}
	
	
		
	
	

?>
<!DOCTYPE html>
<html lang="en">
<head>

  <!-- Basic Page Needs
  –––––––––––––––––––––––––––––––––––––––––––––––––– -->
  <meta charset="utf-8">
  <title><?php echo $site_title_int; ?> | Meal List</title>
  <meta name="<?php echo $site_sologun; ?>" content="">
  <meta name="Nazmul Alam Shuvo" content="">

  <!-- Mobile Specific Metas
  –––––––––––––––––––––––––––––––––––––––––––––––––– -->
  <meta name="viewport" content="width=device-width, initial-scale=1">

  <!-- FONT
  –––––––––––––––––––––––––––––––––––––––––––––––––– -->
  <link href="//fonts.googleapis.com/css?family=Raleway:400,300,600" rel="stylesheet" type="text/css">

  <!-- CSS
  –––––––––––––––––––––––––––––––––––––––––––––––––– -->
  <link rel="stylesheet" href="css/normalize.css">
  <link rel="stylesheet" href="css/skeleton.css">
<style type="text/css">

a { text-decoration : none; color : #000; }

</style>
  <!-- Favicon
  –––––––––––––––––––––––––––––––––––––––––––––––––– -->
  <link rel="icon" type="image/png" href="images/favicon.png">

</head>
<body>

  <!-- Primary Page Layout
  –––––––––––––––––––––––––––––––––––––––––––––––––– -->
  <div class="container">
  <br>
   <div class="row">
   <div class="eleven columns"><a href="index.php"><h4><?php echo $login_session_hostelname; ?></h4>  </a><h6><?php echo $site_sologun; ?></h6></div>
    <div class="one column"><font color="red"><strong><a style="text-decoration : none;" href="logout.php">Logout</a></strong></font></div>
    
  </div>
  <hr>
	
  <font align="center">
	<h4>Meal List</h4>
	<h6><font color = "green"><?php echo $msg; ?></font></h6>
  </font>
  
 
  <table class="u-full-width">
  <thead>
    <tr>
      <th>Boders Name</th>
      <th>Meal</th>
      <th>Guest</th>
      <th>Total</th>
	  <th>Date</th>
	
      
    </tr>
  </thead>
  <?php
	
	$total_meal = "0";
	$total_guest_meal = "0";
	$total_total = "0";
  
  ?>
  <tbody>
   <?php while($row = mysqli_fetch_array($search_result))
   {?>
	  <tr>
      <td><?php echo $row['bodersName']; ?> </td>
	  <?php $meal = $row['meal']; 
			$total_meal = $total_meal + $meal;
			?>
      <td><?php echo $row['meal']; ?></td>
	  
	  <?php $meal = $row['guestMeal']; 
			$total_guest_meal = $total_guest_meal + $meal;
			?>
      <td><?php echo $row['guestMeal']; ?></td>
	  
			<?php $meal = $row['meal']; 
				  $guest = $row['guestMeal'];
				  $total = $meal + $guest;
			?>
	  <td><?php echo $total; 
				$total_total = $total_total + $total; 
			?></td>
	  <td><?php echo $row['date']; ?></td>
      </tr>
   
   <?php };?>
		
	  <tr>
      <td><font color = "red"><b><?php echo "Total - "; ?></b></font> </td>
      <td><font color = "red"><b><?php echo $total_meal; ?></b></font></td>
      <td><font color = "red"><b><?php echo $total_guest_meal; ?></b></font></td>
			<?php $meal = $row['meal']; 
				  $guest = $row['guestMeal'];
				  $total = $meal + $guest;
			?>
	  <td><font color = "red"><b><?php echo $total_total; ?></b></font></td>
	  <td><font color = "red"><b></b></font></td>
      <td><font color = "red"><b></b></font></td>
    </tr>
    

  </tbody>
</table>

 <br>
  <hr>
 <font size="2px" align="center">(c) <?php echo $site_title; ?></font>
  
<br><br>
  </div>

<!-- End Document
  –––––––––––––––––––––––––––––––––––––––––––––––––– -->
</body>
</html>
