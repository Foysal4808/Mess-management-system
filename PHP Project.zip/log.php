<?php
	
	require_once("site_settings.php");
	include('config.php');
	include('session.php');
	
	
	$ii="0";
	$meal_cal="";
?>
<!DOCTYPE html>
<html lang="en">
<head>

  <!-- Basic Page Needs
  –––––––––––––––––––––––––––––––––––––––––––––––––– -->
  <meta charset="utf-8">
  <title><?php echo $site_title_int; ?> | Calculator </title>
  <meta name="<?php echo $site_sologun; ?>" content="">
  <meta name="Nazmul Alam Shuvo" content="">

  <!-- Mobile Specific Metas
  –––––––––––––––––––––––––––––––––––––––––––––––––– -->

  <meta name="viewport" content="width=device-width, initial-scale=1">

  <!-- FONT
  –––––––––––––––––––––––––––––––––––––––––––––––––– -->
  <link href="//fonts.googleapis.com/css?family=Raleway:400,300,600" rel="stylesheet" type="text/css">

  <!-- CSS
  –––––––––––––––––––––––––––––––––––––––––––––––––– -->
  <link rel="stylesheet" href="css/normalize.css">
  <link rel="stylesheet" href="css/skeleton.css">
  	
	<link rel="stylesheet" href="css/col.css" media="all">
	<link rel="stylesheet" href="css/5cols.css" media="all">
	
<style type="text/css">

a { text-decoration : none; color : #000; }

</style>

  <!-- Favicon
  –––––––––––––––––––––––––––––––––––––––––––––––––– -->
  <link rel="icon" type="image/png" href="images/favicon.png">


</head>
<body bgcolor="#ececec">

  <!-- Primary Page Layout
  –––––––––––––––––––––––––––––––––––––––––––––––––– -->
  <div class="container">
  <br>
   <div class="row">
   <div class="eleven columns"><a href="index.php"><h4><?php echo $login_session_hostelname; ?></a></h4>  <h6><?php echo $site_sologun; ?></h6></div>
    <div class="one column"><font color="red"><strong><a href="logout.php">Logout</a></strong></font></div>
    
  </div>
  <hr>
					<?php 
								
								$id="";
								$tamount = "";
								$conn = mysql_connect($database_server, $database_username, $database_password);
								$sql = "SELECT * from users WHERE hostel = '$login_session_hostelname'";

								mysql_select_db('$database');
								$retval = mysql_query( $sql, $conn );
								
								$row = mysql_fetch_array($retval, MYSQL_ASSOC)
								
									
									
								
					
					?>
					
					<?php
						
							$erp="";
							$msg = "";
							if(isset($_GET['erp'])){
								
								$erp=$_GET['erp'];
								$id=$_GET['id'];
							}
							$erpp="";
							if(isset($_GET['erpp'])){
								
								$erpp=$_GET['erpp'];
							}
							if($erpp=='ok'){
								
								$msg = "Sussesful Update.";
							}
							
								if($erp=='save')
							{
								
								$pass1 = $_POST['pass1'];
								$pass2 = $_POST['pass2'];
								
								
								$updateBy = $login_session_username;
								$hostel= $login_session_hostelname;
								if($pass1 == $pass2){
									
									$password_new = $pass1;
									$a_sql=mysql_query("UPDATE users SET password='$password_new' WHERE id='$id'");
								if($a_sql)
								{
									
									header("Location: profile.php?erpp=ok");
									$msg = "Sussesful Update.";
								}
									
								}else{
									$msg = "Password don't match";
								}
								
							} ?><h6><font color = "green"><?php echo $msg; ?></font></h6><?php
							
							if($erp == 'pass'){ ?>
							
								
								<form action="profile.php?erp=save&id=<?php echo $row['id']; ?>" method="post">
								<label for="exampleEmailInput">Your Password</label>
								<input class="u-full-width" name="pass1" type="text" placeholder="******" id="exampleEmailInput">
								<label for="exampleEmailInput">Re-Password</label>
								<input class="u-full-width" name="pass2" type="text" placeholder="******" id="exampleEmailInput">
								
								<input class="button-primary" name="save" type="submit" value="Save">
								</form>
							<?php }
							
						
						
					?>
					
					  <font align="center">
	<h4>Monthly Calculator </h4>
	
  </font>
					<?php 
								$tamount = "";
								$conn = mysql_connect($database_server, $database_username, $database_password);
								$sql = "SELECT * from bazaars WHERE hostel = '$login_session_hostelname'";

								mysql_select_db('$database');
								$retval = mysql_query( $sql, $conn );
								
								while($row = mysql_fetch_array($retval, MYSQL_ASSOC))
								{
									$tamount= $tamount + $row['amount'];
									
								}
					
					?>
					<div class="row">
					<div class="two columns"><strong>Total Bazaar - </strong></div>
					<div class="ten columns"><font color="red"><?php echo $tamount; ?></font></div>
				    </div>
					
					<?php 
								$account = "";
								$conn = mysql_connect($database_server, $database_username, $database_password);
								$sql = "SELECT * from account WHERE hostel = '$login_session_hostelname'";

								mysql_select_db('$database');
								$retval = mysql_query( $sql, $conn );
								
								while($row = mysql_fetch_array($retval, MYSQL_ASSOC))
								{
									$account= $account + $row['taka'] + $row['previous'];
									
								}
					
					?>
					<div class="row">
					<div class="two columns"><strong>Total Fund -  </strong></div>
					<div class="ten columns"><?php echo $account; ?></div>
				    </div>
						<?php 
								$meal = "";
								$conn = mysql_connect($database_server, $database_username, $database_password);
								$sql = "SELECT * from meal WHERE hostel = '$login_session_hostelname'";

								mysql_select_db('$database');
								$retval = mysql_query( $sql, $conn );
								
								while($row = mysql_fetch_array($retval, MYSQL_ASSOC))
								{
									$meal= $meal + $row['meal'] + $row['guestMeal'];
									
								}
					
					?>
					<div class="row">
					<div class="two columns"><strong>Total Meal - </strong></div>
					<div class="ten columns"><?php echo $meal; ?></div>
				    </div>
					<div class="row">
					<div class="two columns"><strong>Meal Rate - </strong></div>
					<div class="ten columns"><?php $meal_rate="0"; if($tamount !=0 || $meal !=0){$meal_rate = $tamount / $meal; }echo (int)$meal_rate+1; $meal_cal=(int)$meal_rate+1; ?></div>
				    </div>
					<?php 
								$account1 = "";
								$conn = mysql_connect($database_server, $database_username, $database_password);
								$sql = "SELECT * from account WHERE hostel = '$login_session_hostelname' AND username = '$login_session_username'";

								mysql_select_db('$database');
								$retval = mysql_query( $sql, $conn );
								
								while($row = mysql_fetch_array($retval, MYSQL_ASSOC))
								{
									$account1= $account1 + $row['taka'] + $row['previous'];
									
								}
					
					?>
					<div class="row">
					<div class="two columns"><strong>Your Balance: </strong></div>
					<div class="ten columns"><?php echo $account1; ?></div>
				    </div>
					<?php 
								$meal1 = "";
								$conn = mysql_connect($database_server, $database_username, $database_password);
								$sql = "SELECT * from meal WHERE hostel = '$login_session_hostelname' AND bodersName = '$login_session_username'";

								mysql_select_db('$database');
								$retval = mysql_query( $sql, $conn );
								
								while($row = mysql_fetch_array($retval, MYSQL_ASSOC))
								{
									$meal1= $meal1 + $row['meal'] + $row['guestMeal'];
									
								}
					
					?>
					
					
					<div class="row">
					<div class="two columns"><strong>Your Meal: </strong></div>
					<div class="ten columns"><font color="red"><?php echo $meal1; ?></font></div>
				    </div>
					
					<div class="row">
					<div class="two columns"><strong>Your Total Cost: </strong></div>
					<div class="ten columns"><font color="red"><?php echo $meal1*$meal_cal; ?></font></div>
				    </div>
					
					<div class="row">
					<div class="two columns"><strong>Remining Balance: </strong></div>
					<div class="ten columns"><font color="red"><?php $result=$account1-($meal1*$meal_cal); if($result >0){echo $result;}else{ echo "$result - Please Pay the amount as soon as possible."; } ?></font></div>
				    </div>
					
					
					
					<br>
					
  <br>
  <br>
  <br>
  <hr>
 <font size="2px" align="center">(c) <?php echo $site_title; ?></font>
  
<br><br>
  </div>
  

		
  
 

<!-- End Document
  –––––––––––––––––––––––––––––––––––––––––––––––––– -->
</body>
</html>
