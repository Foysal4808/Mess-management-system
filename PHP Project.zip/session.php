<?php

	include('config.php');
	$connection=mysql_connect($database_server,$database_username,$database_password);

	$db=mysql_select_db($database,$connection);

	session_start();

	$user_check=$_SESSION['login_user'];
	$hostel_name=$_SESSION['hostel'];
	

	$ses_sql=mysql_query("SELECT * FROM `users` WHERE `username`='$user_check' AND `hostel`='$hostel_name'",$connection);
	$row=mysql_fetch_array($ses_sql);
	$login_session=$row['power'];
	$login_session_userid=$row['id'];
	$login_session_username=$row['username'];
	$login_session_hostelname=$row['hostel'];
	
	
	

if(!isset($login_session)){
	
	
	mysql_close($connection);
	header("Location: login.php");
}



?>