<?php
	//Nazmul alam shuvo
	
	
	//Database config:
	
	$database_server = "127.0.0.1";
	$database_username = "root";
	$database_password = "12345";
	$database = "hms";
	
?>