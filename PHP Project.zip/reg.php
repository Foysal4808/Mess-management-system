<?php
	require_once('Protector.php');
	require_once("site_settings.php");
	require_once("config.php");
	
	
	$msg = "";
	if(isset($_POST['add']))
	{
		$username = $_POST['username'];
		$name = $_POST['name'];
		$password = $_POST['password'];
		$power = "1";
		$hostel= $_POST['hostel'];
		$mobile=$_POST['mobile'];
		$nid=$_POST['nid'];
		$notice="Welcome to our System!!";
		

// Create connection
$conn = new mysqli($database_server, $database_username, $database_password, $database);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 

$sql = "INSERT INTO `$database`.`users` (`id`, `username`, `password`, `power`, `hostel`, `mobile`, `nid`, `name`) VALUES (NULL, '$username', '$password', '$power', '$hostel', '$mobile', '$nid', '$name');";
$sql1 = "INSERT INTO `$database`.`notice` (`id`, `notice`, `updateBy`, `hostel`) VALUES (NULL, '$notice', '$username', '$hostel');";

if ($conn->query($sql) === TRUE && $conn->query($sql1) == TRUE ){
    $msg = "Admin Added successfully";
} else {
    $msg = "Error: " . $sql . "<br>" . $conn->error;
}
	}


	
?>
<!DOCTYPE html>
<html lang="en">
<head>

  <!-- Basic Page Needs
  –––––––––––––––––––––––––––––––––––––––––––––––––– -->
  <meta charset="utf-8">
  <title><?php echo $site_title_int; ?> | Registration </title>
  <meta name="<?php echo $site_sologun; ?>" content="">
  <meta name="Nazmul Alam Shuvo" content="">

  <!-- Mobile Specific Metas
  –––––––––––––––––––––––––––––––––––––––––––––––––– -->
  <meta name="viewport" content="width=device-width, initial-scale=1">

  <!-- FONT
  –––––––––––––––––––––––––––––––––––––––––––––––––– -->
  <link href="//fonts.googleapis.com/css?family=Raleway:400,300,600" rel="stylesheet" type="text/css">

  <!-- CSS
  –––––––––––––––––––––––––––––––––––––––––––––––––– -->
  <link rel="stylesheet" href="css/normalize.css">
  <link rel="stylesheet" href="css/skeleton.css">
<style type="text/css">

a { text-decoration : none; color : #000; }

</style>
  <!-- Favicon
  –––––––––––––––––––––––––––––––––––––––––––––––––– -->
  <link rel="icon" type="image/png" href="images/favicon.png">

</head>
<body>

  <!-- Primary Page Layout
  –––––––––––––––––––––––––––––––––––––––––––––––––– -->
  <div class="container">
  <br>
   <div class="row">
   <div class="eleven columns"><a href="index.php"><h4>HMS</h4> </a> <h6><?php echo $site_sologun; ?></h6></div>

    
  </div>
  <hr>
	
  <font align="center">
	<h4>Registration Admin</h4>
	<h6><font color = "green"><?php echo $msg; ?></font></h6>
  </font>
  <form action="reg.php" method="post">
	
		<label for="exampleEmailInput">Admin Username: </label>
	    <input class="u-full-width" type="text" name="username" placeholder="Ex: shuvo" id="Naim">
		<label for="exampleEmailInput">Admin Password: </label>
	    <input class="u-full-width" type="password" name="password" placeholder="******" id="Naim">
		<label for="exampleEmailInput">Full Name: </label>
	    <input class="u-full-width" type="text" name="name" placeholder="Ex: Nazmul Alam Shuvo" id="Naim">
		<label for="exampleEmailInput">Hostel Name: </label>
	    <input class="u-full-width" type="text" name="hostel" placeholder="Ex: Happy House" id="Naim">
		<label for="exampleEmailInput">Mobile: </label>
	    <input class="u-full-width" type="text" name="mobile"previous" placeholder="017371XXXXX" id="Naim">
		<label for="exampleEmailInput">NID Number:</label>
	    <input class="u-full-width" type="text" name="nid" placeholder="Ex: 1996XXXXXXX" id="Naim">
		
		
		
		<input class="button-primary" type="submit" name="add" value="Submit">
		
  </form>
 <br>
  <hr>
 <font size="2px" align="center">(c) Hostel Management System 2017</font>
  
<br><br>
  </div>

<!-- End Document
  –––––––––––––––––––––––––––––––––––––––––––––––––– -->
</body>
</html>
