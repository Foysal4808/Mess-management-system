<?php
	//nazmul alam shuvo
	
	$site_title = "Hostel Management System";
	$site_title_int = "HMS";
	$site_sologun = "A Hostel Manegnent System";

?>