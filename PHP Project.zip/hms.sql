-- phpMyAdmin SQL Dump
-- version 4.2.11
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Apr 20, 2017 at 06:58 PM
-- Server version: 5.6.21
-- PHP Version: 5.6.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `hms`
--

-- --------------------------------------------------------

--
-- Table structure for table `account`
--

CREATE TABLE IF NOT EXISTS `account` (
`id` int(11) NOT NULL,
  `username` varchar(30) DEFAULT NULL,
  `taka` int(11) DEFAULT NULL,
  `date` varchar(10) DEFAULT NULL,
  `hostel` varchar(20) DEFAULT NULL,
  `previous` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `bazaars`
--

CREATE TABLE IF NOT EXISTS `bazaars` (
`id` int(11) NOT NULL,
  `username` varchar(30) DEFAULT NULL,
  `bazaars` varchar(300) DEFAULT NULL,
  `amount` int(11) DEFAULT NULL,
  `date` varchar(10) DEFAULT NULL,
  `hostel` varchar(30) DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `bazaars`
--

INSERT INTO `bazaars` (`id`, `username`, `bazaars`, `amount`, `date`, `hostel`) VALUES
(1, 'shuvo', 'alu', 20, '23-02-2017', 'Guest House');

-- --------------------------------------------------------

--
-- Table structure for table `clening`
--

CREATE TABLE IF NOT EXISTS `clening` (
`id` int(11) NOT NULL,
  `username` varchar(30) DEFAULT NULL,
  `date` varchar(10) DEFAULT NULL,
  `hostel` varchar(30) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `meal`
--

CREATE TABLE IF NOT EXISTS `meal` (
`id` int(11) NOT NULL,
  `bodersName` varchar(100) DEFAULT NULL,
  `meal` varchar(10) DEFAULT NULL,
  `guestMeal` varchar(10) DEFAULT NULL,
  `date` varchar(10) DEFAULT NULL,
  `hostel` varchar(50) DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `notice`
--

CREATE TABLE IF NOT EXISTS `notice` (
`id` int(11) NOT NULL,
  `notice` varchar(500) DEFAULT NULL,
  `updateBy` varchar(30) DEFAULT NULL,
  `hostel` varchar(30) DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `notice`
--

INSERT INTO `notice` (`id`, `notice`, `updateBy`, `hostel`) VALUES
(1, 'Welcome to our System!!', 'rootq', 'Amar Bariw');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE IF NOT EXISTS `users` (
`id` int(11) NOT NULL,
  `username` varchar(50) DEFAULT NULL,
  `password` varchar(50) DEFAULT NULL,
  `power` varchar(1) DEFAULT NULL,
  `hostel` varchar(50) DEFAULT NULL,
  `mobile` int(11) DEFAULT NULL,
  `nid` varchar(30) DEFAULT NULL,
  `name` varchar(30) DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `password`, `power`, `hostel`, `mobile`, `nid`, `name`) VALUES
(4, 'rootq', '123452', '1', 'Amar Bariw', 1737161107, '1996543210', 'we');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `account`
--
ALTER TABLE `account`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `bazaars`
--
ALTER TABLE `bazaars`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `clening`
--
ALTER TABLE `clening`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `meal`
--
ALTER TABLE `meal`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `notice`
--
ALTER TABLE `notice`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
 ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `account`
--
ALTER TABLE `account`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `bazaars`
--
ALTER TABLE `bazaars`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `clening`
--
ALTER TABLE `clening`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `meal`
--
ALTER TABLE `meal`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `notice`
--
ALTER TABLE `notice`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=6;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
