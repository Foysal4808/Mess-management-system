<?php

     require_once("site_settings.php");
	 require_once("config.php");
	 
	 
$login_error="";

if(isset($_POST['login']))
{
	session_start();
	if(empty($_POST['username'])||empty($_POST['password']))
	{
		$login_error="Username or Password invalid!";
	}else{
		$username=$_POST['username'];
		$password=$_POST['password'];
		
		$connection=mysql_connect($database_server,$database_username,$database_password);
		
		$username=stripslashes($username);
		$password=stripslashes($password);
		$username=mysql_real_escape_string($username);
		$password=mysql_real_escape_string($password);
		
		$db=mysql_select_db($database,$connection);
		
		$query=mysql_query("SELECT * FROM `users` WHERE `password`='$password' AND `username`='$username'",$connection);
		
		$rows=mysql_num_rows($query);
		$row = mysql_fetch_array($query, MYSQL_ASSOC);
		
		
		
		
		if($rows==1){
			if($row['power']==1){
				$_SESSION['login_user']=$username;
				$_SESSION['hostel']=$row['hostel'];
				header("location: admin/index.php");
				}else{
			$_SESSION['login_user']=$username;
			$_SESSION['hostel']=$row['hostel'];
			header("location: index.php");
			}
		}else{
			$login_error="Username Or Pass Wrong";
		}
		mysql_close($connection);
	}
}

?>
<!DOCTYPE html>
<html lang="en">
<head>

  <!-- Basic Page Needs
  –––––––––––––––––––––––––––––––––––––––––––––––––– -->
  <meta charset="utf-8">
  <title><?php echo $site_title_int; ?> | Login </title>
  <meta name="A hostel menagment system (HMS)" content="">
  <meta name="Nazmul Alam Shuvo" content="">

  <!-- Mobile Specific Metas
  –––––––––––––––––––––––––––––––––––––––––––––––––– -->
  <meta name="viewport" content="width=device-width, initial-scale=1">

  <!-- FONT
  –––––––––––––––––––––––––––––––––––––––––––––––––– -->
  <link href="//fonts.googleapis.com/css?family=Raleway:400,300,600" rel="stylesheet" type="text/css">

  <!-- CSS
  –––––––––––––––––––––––––––––––––––––––––––––––––– -->
  <link rel="stylesheet" href="css/normalize.css">
  <link rel="stylesheet" href="css/skeleton.css">

  <!-- Favicon
  –––––––––––––––––––––––––––––––––––––––––––––––––– -->
  <link rel="icon" type="image/png" href="images/favicon.png">

</head>
<body>

  <!-- Primary Page Layout
  –––––––––––––––––––––––––––––––––––––––––––––––––– -->
  <div class="container">
  <br>
  <br>
  <font align="center"><h4><?php echo $site_title; ?></h4><h6>| Login |</h6></font>
  <br>

<div class="container">
<p><font color="red"> <?php echo $login_error; ?></font></p>
  <div class="row">
  <form action = "login.php" method = "post">
	<label for="exampleEmailInput">Username</label>
	<input class="u-full-width" type="text" placeholder="Ex: admin" name="username">
	<label for="exampleEmailInput">Password</label>
	<input class="u-full-width" type="password" name="password"></p>
	<input class="button-primary" type="submit" value="login" name="login">
	</form>
  </div>
 </div>
 <hr>
 <font size="2px" align="center">(c) <?php echo $site_title; ?></font>
  
  </div>

<!-- End Document
  –––––––––––––––––––––––––––––––––––––––––––––––––– -->
</body>
</html>
