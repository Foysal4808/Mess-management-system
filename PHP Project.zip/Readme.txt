Please Change the information to :

		1. site_setting.php
		2. config.php
		3. Protector.php
	And create import database hms.sql to mysqlserver.

	Please hit reg.php to Registar AdminUser.